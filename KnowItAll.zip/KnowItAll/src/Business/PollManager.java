package Business; 

import java.util.ArrayList;



public class PollManager {

	private ArrayList<Poll> polls; // list of current polls being displayed
	private int numPolls; 
	
	
	public Poll getPoll(int pollID) {
		for (int i = 0; i < polls.size(); i++) {
			Poll poll = polls.get(i); 
			if (poll.getID() == pollID) {
				return poll; 
			}
		}
		return null;
	}
	
	public void addPoll(Poll newPoll) {
		polls.add(newPoll);
		numPolls++;
	}
	
	public ArrayList<Poll> sortByPopularity() {
		ArrayList<Poll> sortedList = new ArrayList<Poll>();
		sortedList.add(polls.get(0));
		for (int i = 1; i < polls.size(); i++) {
			Poll unsortedPoll = polls.get(i);
			int insertPoint = (sortedList.size()/2);

			if (unsortedPoll.getNumViews()< sortedList.get(insertPoint).getNumViews()) {
				while (unsortedPoll.getNumViews() < sortedList.get(insertPoint).getNumViews()) {
					insertPoint++; 
				}
				sortedList.add(insertPoint, unsortedPoll);
			}
			else if (unsortedPoll.getNumViews() > sortedList.get(insertPoint).getNumViews()){
				while (unsortedPoll.getNumViews() > sortedList.get(insertPoint).getNumViews()) {
					insertPoint--; 
				}
				sortedList.add(insertPoint, unsortedPoll);
			}
			else {
				sortedList.add(insertPoint, unsortedPoll);
			}
		}
		return sortedList;
	}
	
	public void newVote(int pollID, String choice) {
		// if user hasn't already voted on this poll
		for (int i = 0; i < polls.size(); i++) {
			Poll poll = polls.get(i);
			if (poll.getID() == pollID) {
				poll.vote(choice);
			}
		}
	}
	
	public void newComment(int pollID, String userEmail, String newComment, Boolean isAnon) { // added userEmail as a parameter
		CommentAction comment = new CommentAction(isAnon, userEmail, pollID, newComment);
		for (int i = 0; i < polls.size(); i++) {
			Poll poll = polls.get(i);
			if (poll.getID() == pollID) {
				poll.addComment(comment);
			}
		}
	}
	
	public ArrayList<Poll> searchPolls(String search) {
		ArrayList<Poll> searchResults = new ArrayList<Poll>(); 
		for (int i = 0; i < polls.size(); i++) {
			String pollTitle = polls.get(i).getTitle();
			if (pollTitle.contains(search)) {
				searchResults.add(polls.get(i));
			}
		}
		return searchResults; 
	}
	
	public void addView(int pollID) {
		Poll poll = this.getPoll(pollID);
		poll.addView();
	}
	public int getNumPolls() {
		return numPolls;
	}
	
	public void setPollList(ArrayList<Poll> polls){
		this.polls = polls;
	}
}