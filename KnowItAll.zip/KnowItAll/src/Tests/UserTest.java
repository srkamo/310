package Tests;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

import Business.User;

public class UserTest {
	@Test
	public void testGetFName() {
		User u = new User("monger@usc.edu", "12345", "Natalie", "Monger", null, null); 
		String fName = u.getFName(); 
		assertEquals("Natalie", fName);
	}
	
	@Test
	public void testGetLName() {
		User u = new User("monger@usc.edu", "12345", "Natalie", "Monger", null, null); 
		String lName = u.getLName(); 
		assertEquals("Monger", lName);
	}
	
	@Test
	public void testGetEmail() {
		User u = new User("monger@usc.edu", "12345", "Natalie", "Monger", null, null); 
		String email = u.getEmail(); 
		assertEquals("monger@usc.edu", email);
	}
	@Test
	public void testGetPassword() {
		User u = new User("monger@usc.edu", "12345", "Natalie", "Monger", null, null); 
		String password = u.getPassword(); 
		assertEquals("12345", password);
	}
	
	public static void main(String [] args){
		UserTest ut = new UserTest(); 
		ut.testGetFName(); 
		ut.testGetLName();
		ut.testGetEmail();
		ut.testGetPassword(); 
	}
}