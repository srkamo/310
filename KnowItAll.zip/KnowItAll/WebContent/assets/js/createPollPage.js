$(document).ready(function (){
	$('.add-option button').click(function(e){
		e.preventDefault();
		console.log('here')
		$('.add-option').prepend('<input/>')
	})
});