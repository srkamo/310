package backend;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Email: ");
		  Scanner sc = new Scanner(System.in);
		  String i = sc.nextLine();
		  
		  Boolean  v = EmailVerifier.validate(i);
		  
		  System.out.println("valid: " + v);
	}

}
