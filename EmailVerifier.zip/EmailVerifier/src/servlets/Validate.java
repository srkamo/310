package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;

import backend.EmailVerifier;


/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		PrintWriter out = response.getWriter();
		
		String email = request.getParameter("emailInput");
		
		System.out.println("email input: " + email);
		
		Boolean valid = false;
		
		valid = EmailVerifier.validate(email);
		
		System.out.println("valid: " + valid);
		
		if(valid){
			request.setAttribute("valid", "VALID EMAIL");
		}
		else{
			request.setAttribute("valid", "INVALID EMAIL");
			
		}
		
		request.getRequestDispatcher("login.jsp").forward(request, response);
		
	}

	

}
