package Business;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import Database.Database;

public class KingManager {

	private Database database;
	private EntityManager entityManager;
	private PollManager pollManager;
	private User curUser;
	

	private int ids;
	
	public KingManager(){
		database  = new Database();
		entityManager = new EntityManager();
		pollManager = new PollManager();
		ids = database.getNumThings();
		curUser = null;
	}
	
	
	public User getCurUser() {
		return curUser;
	}

	public void setCurUser(User curUser) {
		this.curUser = curUser;
	}
	
	public ArrayList<Object> search(String search){
		System.out.println("wya " + search);
		ArrayList<Entity> entities = database.searchForEntities(search);
		System.out.println("entities size: " + entities.size());
		entityManager.setEntityList(entities);
		ArrayList<Poll> polls = database.searchForPolls(search);
		pollManager.setPollList(polls);
		
		ArrayList<Object> all = new ArrayList<Object>();
		all.addAll(entities);
		all.addAll(polls);
		
		Collections.sort(all, new Comparator<Object>() {
			public int compare(Object o1, Object o2){
				int numViews1 = 0, numViews2 = 0;
				if(o1 instanceof Entity){
					numViews1 = ((Entity)o1).getNumViews();
				}
				else if(o1 instanceof Poll){
					numViews1 = ((Poll)o1).getNumViews();
				}
				
				if(o2 instanceof Entity){
					numViews2 = ((Entity)o2).getNumViews();
				}
				else if(o2 instanceof Poll){
					numViews2 = ((Poll)o2).getNumViews();
				}
				
				
				return numViews2 - numViews1;
				
			}
		});
		
		System.out.println("all size: " + all.size());
		return all;
	}//search()
	
/*----------------Database------------------------------- */
	public User getUser(String email){
		return database.getUser(email);
	}
	
	public void addUser(User newUser){
		database.addUser(newUser);
	}	

/*----------------EntityManager------------------------------- */
	public Entity getEntity(int entityID){
		return entityManager.getEntity(entityID);
	}
	
	public void addEntity(Entity newEntity){
		database.addEntity(newEntity);
		entityManager.addEntity(newEntity);
		ids++;
	}
	
	public void newRating(int entityID, Boolean upVote, String userEmail, Boolean isAnon) {
		entityManager.newRating(entityID, upVote);
		Action action = new Action(isAnon, userEmail, entityID);
		database.addAction(action);
	}
	
	public void newEntityComment(int entityID, String userEmail, String newComment, Boolean isAnon) { 
		entityManager.newComment(entityID, userEmail, newComment);
		Action action = new Action(isAnon, userEmail, entityID);
		database.addAction(action);
	}
	
	public void addEntityView(int entityID) {
		entityManager.addView(entityID);
		database.addNumView(entityID, "Entity");
	}

/*----------------PollManager------------------------------- */
	public Poll getPoll(int pollID){
		return pollManager.getPoll(pollID);
	}
	
	public void addPoll(Poll newPoll){
		database.addPoll(newPoll);
		pollManager.addPoll(newPoll);
		ids++;
	}
	
	public void addPollView(int pollID) {
		pollManager.addView(pollID);
		database.addNumView(pollID, "Poll");
	}
	
	public void newVote(int pollID, String choice, Boolean isAnon, String userEmail) {
		pollManager.newVote(pollID, choice);
		Action action = new Action(isAnon, userEmail, pollID);
		database.addAction(action);
	}
	
	public void newPollComment(int pollID, String userEmail, String newComment, Boolean isAnon) { 
		pollManager.newComment(pollID, userEmail, newComment);
		Action action = new Action(isAnon, userEmail, pollID);
		database.addAction(action);
	}
	
}
