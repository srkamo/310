import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SeleniumTests {

	@Test
	public void testPollPageScoresAndComments() {
		WebDriver browser;
		
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");
		browser = new FirefoxDriver();
		browser.get("http://localhost:8085/KnowItAll/index.jsp");
		browser.get("http://localhost:8085/KnowItAll/pollPage.jsp?subjectID=1"); 
		
		WebElement scores = browser.findElement(By.id("scores"));
		WebElement comment = browser.findElement(By.id("comment"));

		
		assertTrue((scores.isDisplayed()));
		assertTrue((comment.isDisplayed()));
		browser.close();
	}
	
	@Test
	public void testEntityPageRatingAndComments(){
		WebDriver browser;
		
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");
		browser = new FirefoxDriver();
		browser.get("http://localhost:8085/KnowItAll/index.jsp");
		browser.get("http://localhost:8085/KnowItAll/entityPage.jsp?subjectID=2"); 
		
		WebElement rating = browser.findElement(By.id("rating"));
		WebElement comment = browser.findElement(By.id("comment"));

		
		assertTrue((rating.isDisplayed()));
		assertTrue((comment.isDisplayed()));
		browser.close();
	}
	
	@Test 
	public void testUserCanOnlyVoteOnce(){
		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
		
		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signinform = browser.findElement(By.name("signinform"));
	    WebElement usernameElement = browser.findElement(By.name("l_email"));
		WebElement passwordElement = browser.findElement(By.name("l_password"));
		
		usernameElement.sendKeys("mbent@usc.edu");
	    passwordElement.sendKeys("password3");
		
	    signinform.submit(); 

		browser.get("http://localhost:8085/KnowItAll/pollPage.jsp?subjectID=11"); 
		
		WebElement submitVoteForm = browser.findElement(By.name("submitVoteForm"));
	    submitVoteForm.submit(); 
	    WebElement submitVoteForm2 = browser.findElement(By.name("submitVoteForm"));
	    submitVoteForm2.submit(); 

	    //check the browser -- there shoud be an error message on the poll page saying that 
	    //the user has already voted on this poll
	}
	
	@Test 
	public void testCreatePollPage(){
		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
	
		browser.get("http://localhost:8085/KnowItAll/createPollPage.jsp"); 
		
		assertTrue(browser.getCurrentUrl().equals("http://localhost:8080/KnowItAll/createPollPage.jsp"));
		browser.close();
	}
	
	@Test
	public void testUserPageFeedUpdates(){
		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
		
		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signinform = browser.findElement(By.name("signinform"));
	    WebElement usernameElement = browser.findElement(By.name("l_email"));
		WebElement passwordElement = browser.findElement(By.name("l_password"));
		
		usernameElement.sendKeys("mbent@usc.edu");
	    passwordElement.sendKeys("password3");
		
	    signinform.submit(); 

		browser.get("http://localhost:8085/KnowItAll/pollPage.jsp?subjectID=11"); 
		
		WebElement submitVoteForm = browser.findElement(By.name("submitVoteForm"));
	    submitVoteForm.submit(); 
	   
	    browser.get("http://localhost:8085/KnowItAll/userPage.jsp"); 
	    WebElement historyElement = browser.findElement(By.id("userHistory"));
	    
	    assertTrue(historyElement.isDisplayed());

	    //check the browser -- there shoud be an error message on the poll page saying that 
	    //the user has already voted on this poll
	}
	
	@Test 
	public void searchEntity() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
		browser.get("http://localhost:8085/KnowItAll/feed.jsp"); 
	    
	    WebElement searchform = browser.findElement(By.name("searchform"));
	    WebElement searchtextbar = browser.findElement(By.name("searchTextBar"));
		
		searchtextbar.sendKeys("blaze");
		
	    searchform.submit(); 
	    
	    
	    WebDriverWait wait = new WebDriverWait(browser, 10);
	    WebElement feedElement = wait.until(
	         ExpectedConditions.presenceOfElementLocated(By.name("titleHeading"))
	        );
	    
	    WebElement entityText = browser.findElement(By.name("titleHeading"));
	    
	    assertTrue((entityText.isDisplayed())); 
	    
		


		browser.close();

	}
	
	@Test 
	public void createEntityNotEnoughInfo() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   

		browser.get("http://localhost:8085/KnowItAll/createEntityPage.jsp"); 
	    
	    WebElement createEntityForm = browser.findElement(By.name("createEntityForm"));
	    WebElement title = browser.findElement(By.name("title"));
		
		title.sendKeys("rate a hello");
		
	    createEntityForm.submit(); 
	    
	    browser.findElement(By.name("errorBox"));


		browser.close();

	}
	
	@Test 
	public void createPollLoggedIn() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
		
		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signinform = browser.findElement(By.name("signinform"));
	    WebElement usernameElement = browser.findElement(By.name("l_email"));
		WebElement passwordElement = browser.findElement(By.name("l_password"));
		
		usernameElement.sendKeys("monger@usc.edu");
	    passwordElement.sendKeys("12345");
		
	    signinform.submit(); 

		browser.get("http://localhost:8085/KnowItAll/createPollPage.jsp"); 
	    
	    WebElement createPollForm = browser.findElement(By.name("createPollForm"));
	    WebElement title = browser.findElement(By.name("title"));
	    WebElement tags = browser.findElement(By.name("tags"));
	    WebElement option1 = browser.findElement(By.name("option1"));
		WebElement option2 = browser.findElement(By.name("option2"));
		WebElement date = browser.findElement(By.name("date"));
		WebElement image = browser.findElement(By.name("image"));
		
		title.sendKeys("which greeting is better?"); 
		tags.sendKeys("hi, hey, hello, hola"); 
		option1.sendKeys("hi");
		option2.sendKeys("hey");
	    date.sendKeys("11/18/2018");
	    image.sendKeys("http://archtopmusictherapy.com/wp-content/uploads/2016/09/Wave-Your-Hand.png");
		
	    createPollForm.submit(); 

		//browser.close();

	}
	
	@Test 
	public void createPollNotLoggedIn() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   

		browser.get("http://localhost:8085/KnowItAll/createPollPage.jsp"); 
	    
	    WebElement createPollForm = browser.findElement(By.name("createPollForm"));
	    WebElement title = browser.findElement(By.name("title"));
	    WebElement tags = browser.findElement(By.name("tags"));
	    WebElement option1 = browser.findElement(By.name("option1"));
		WebElement option2 = browser.findElement(By.name("option2"));
		WebElement date = browser.findElement(By.name("date"));
		WebElement image = browser.findElement(By.name("image"));
		
		title.sendKeys("which greeting is better?"); 
		tags.sendKeys("hi, hey, hello, hola"); 
		option1.sendKeys("hi");
		option2.sendKeys("hey");
	    date.sendKeys("11/18/2018");
	    image.sendKeys("http://archtopmusictherapy.com/wp-content/uploads/2016/09/Wave-Your-Hand.png");
		
	    createPollForm.submit(); 
	    
	    browser.findElement(By.name("errorBox"));


		browser.close();

	}
	
	@Test 
	public void login() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   

		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signinform = browser.findElement(By.name("signinform"));
	    WebElement usernameElement = browser.findElement(By.name("l_email"));
		WebElement passwordElement = browser.findElement(By.name("l_password"));
		
		usernameElement.sendKeys("monger@usc.edu");
	    passwordElement.sendKeys("12345");
		
	    signinform.submit(); 
	    
	    WebDriverWait wait = new WebDriverWait(browser, 10);
	    WebElement feedElement = wait.until(
	         ExpectedConditions.presenceOfElementLocated(By.name("searchTextBar"))
	        );
	    
	    browser.findElement(By.name("searchTextBar")); 
		


		browser.close();

	}
	
	@Test 
	public void loginIncorrectPassword() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   

		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signinform = browser.findElement(By.name("signinform"));
	    WebElement usernameElement = browser.findElement(By.name("l_email"));
		WebElement passwordElement = browser.findElement(By.name("l_password"));
		
		usernameElement.sendKeys("monger@usc.edu");
	    passwordElement.sendKeys("123456");
		
	    signinform.submit(); 
	    
	    browser.findElement(By.name("errorBox"));

		browser.close();

	}
	
	@Test 
	public void signUp() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   

		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signupform = browser.findElement(By.name("signupform"));
	    WebElement firstNameElement = browser.findElement(By.name("fName"));
	    WebElement lastNameElement = browser.findElement(By.name("lName"));
	    WebElement usernameElement = browser.findElement(By.name("email"));
		WebElement passwordElement = browser.findElement(By.name("password"));
		
		firstNameElement.sendKeys("Natalie"); 
		lastNameElement.sendKeys("Monger"); 
		usernameElement.sendKeys("monger@usc.edu");
	    passwordElement.sendKeys("12345");
		
	    signupform.submit(); 
	    
	    WebDriverWait wait = new WebDriverWait(browser, 10);
	    WebElement feedElement = wait.until(
	         ExpectedConditions.presenceOfElementLocated(By.name("searchTextBar"))
	        );
	    
	    browser.findElement(By.name("searchTextBar")); 


		browser.close();

	}
	
	@Test 
	public void signUpNonUSCEmail() {   

		WebDriver browser;   

		//Firefox's geckodriver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   

		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	    
	    WebElement signupform = browser.findElement(By.name("signupform"));
	    WebElement firstNameElement = browser.findElement(By.name("fName"));
	    WebElement lastNameElement = browser.findElement(By.name("lName"));
	    WebElement usernameElement = browser.findElement(By.name("email"));
		WebElement passwordElement = browser.findElement(By.name("password"));
		
		firstNameElement.sendKeys("Natalie"); 
		lastNameElement.sendKeys("Monger"); 
		usernameElement.sendKeys("monger@gmail.com");
	    passwordElement.sendKeys("12345");
		
	    signupform.submit(); 
	    
	    browser.findElement(By.name("errorBox"));


		browser.close();

	}
	
	@Test
	public void testPollPageActivityPeriod() {
		WebDriver browser;
		
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");
		browser = new FirefoxDriver();
		browser.get("http://localhost:8085/KnowItAll/index.jsp");
		browser.get("http://localhost:8085/KnowItAll/pollPage.jsp?subjectID=1"); 
		
		WebElement lifespan = browser.findElement(By.id("lifespan"));

		assertTrue((lifespan.isDisplayed()));
		browser.close();
	}
	
	@Test
	public void testEntityPageActivityPeriod(){
		WebDriver browser;
		
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");
		browser = new FirefoxDriver();
		browser.get("http://localhost:8085/KnowItAll/index.jsp");
		browser.get("http://localhost:8085/KnowItAll/entityPage.jsp?subjectID=2"); 
		
		WebElement lifespan = browser.findElement(By.id("lifespan"));

		
		assertTrue((lifespan.isDisplayed()));
		browser.close();
	}
	
	@Test 
	public void voteOnEntityNotLoggedIn() {   

		WebDriver browser;   
   
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");   

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp"); 
		browser.get("http://localhost:8085/KnowItAll/entityPage.jsp?subjectID=1");
		
		// click on browser.findElement(By.cssSelector("#thumbsupdiv > a:nth-child(1)"))
		// then check for browser.findElement(By.cssSelector("h4.info-text:nth-child(2) > center:nth-child(1)"))
		// it should be there
		
		browser.close();
	}
	
	@Test 
	public void testUserMustBeLoggedIn(){
		WebDriver browser;   

		//Firefox's gecko-driver requires you to specify its location.    
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");    

		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
		
		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
	  
		browser.get("http://localhost:8085/KnowItAll/pollPage.jsp?subjectID=11"); 
		
		WebElement submitVoteForm = browser.findElement(By.className("iradio_square-yellow"));
	    submitVoteForm.submit();  

	    //check the browser -- there should be an error message on the poll page saying that 
	    //the user has already voted on this poll
	}

	
	@Test 
	public void testLoggedInPollVote() {
		WebDriver browser;   
		System.setProperty("webdriver.gecko.driver","C:\\Users\\Natalie Monger\\Documents\\geckodriver.exe");    
		
		browser = new FirefoxDriver();    
		browser.get("http://localhost:8085/KnowItAll/index.jsp");   
		
		browser.get("http://localhost:8085/KnowItAll/login.jsp"); 
		
    		WebElement signinform = browser.findElement(By.name("signinform"));
    		WebElement usernameElement = browser.findElement(By.name("l_email"));
		WebElement passwordElement = browser.findElement(By.name("l_password"));
	
		usernameElement.sendKeys("mbent@usc.edu");
    		passwordElement.sendKeys("password3");
	
    		signinform.submit(); 
    		
    		browser.get("http://localhost:8080/KnowItAll/pollPage.jsp?subjectID=11"); 

    		WebElement submitVoteForm = browser.findElement(By.className("iradio_square-yellow"));
    	    submitVoteForm.submit(); 
	}
	

}