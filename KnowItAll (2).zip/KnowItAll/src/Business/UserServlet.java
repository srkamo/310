package Business;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Database.Database;
import Business.User; 

/**
 * Servlet implementation class KickitServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// on startup, get all data from database (or an object that communicates with the database) and put it in a session attribute
		HttpSession session = request.getSession(); 
		Database db = (Database) session.getAttribute("database");
		if(db == null){
			System.out.println("Database is null"); 
		} else {
			System.out.println("Database is NOT null"); 
		}
		
		
		
		// if user chose GUEST, forward them to main page jsp
		
		
		// if user chose SIGN IN or SIGN UP, forward them to login jsp
		// if user chose SIGN UP, push inforamtion to database
		
		String next = "/feed.jsp";
		
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String fName = request.getParameter("fName");
		String lName = request.getParameter("lName");
		
		System.out.println("email " + email);
		System.out.println("password " + password);
		System.out.println("fName " + fName);
		System.out.println("lName " + lName);
		
		if(email == null || password == null || fName == null || lName == null){
			
			System.out.println("Invalid Sign Up. Try again. ");
		} 
		else {
			// Validate Email
			// If email returns true
			User newUser = new User(email, password, fName, lName); 
			db.addUser(newUser);
		  	request.getRequestDispatcher("feed.jsp").include(request,response);

		}
		
		
		
		

		
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		dispatch.forward(request,  response);
	}
}
