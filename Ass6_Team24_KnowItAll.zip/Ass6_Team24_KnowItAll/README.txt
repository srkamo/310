Run KnowItAll by downloading the zip and importing it into a project in Eclipse. 

Run the two sql scripts provided in the project in MySQLWorkbench. 