package Business;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Hash {
	
	public static String hash(String password){
		
		MessageDigest mDigest = null;
		try {
			mDigest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			System.out.println("hashEx: " + e.getMessage());
		}
		mDigest.update(password.getBytes(), 0, password.length());
		return new BigInteger(1, mDigest.digest()).toString(16);
		
	}
	
}
