var count = 3;

$(document).ready(function (){
	$('.add-option button').click(function(e){
		e.preventDefault();
		console.log('here')
		var optionNum = 'option' + count;
		$('.add-option').before(
				'<label>Poll Option ' + count +' <small>(optional)</small></label>' + 
            	'<input name="' + optionNum +'" type="text" class="form-control"> '
				)
		count++;
	})
});